/**
 * Created by amazing on 2018/4/9.
 */
package my_pack;
import java.io.*;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;


public class Eratosthenes {
    //boolean isFirst;
    public static void Gnertae(long max_n,boolean isFirst)
    {
        Date begin = new Date();
        long begin_time = begin.getTime();
        //initial
        String line = "";
        long data;
        ArrayList<Long> prime_list = new ArrayList<Long>();
        ArrayList<Long> new_list = new ArrayList<Long> ();
        //open file
        while (true){
            //initialize
            if(isFirst){
                for(long i = 0; i <= max_n; i++ ){
                    new_list.add(i);
                }
                try {
                    BufferedReader br = new BufferedReader(new FileReader("result.txt"));
                    while ((line = br.readLine())!=null){
                        line.replace("\n","");
                        data = Long.parseLong(line);
                        for (long temp = data*2; temp <= max_n; temp += data ){
                            new_list.remove(temp);
                        }
                    }
                    new_list.remove(0);
                    new_list.remove(0);
                    //copy the prime list and make it in the new file
                    prime_list = new ArrayList (new_list);
                    br.close();
                    //open a new file and record
                    FileWriter fw = new FileWriter("result.txt");
                    for (Object item : prime_list) {
                        fw.write(String.valueOf(item)+'\n');
                    }
                    //list.clear();
                    fw.close();
                }
                catch (Exception e)
                {
                    System.out.println(e.getMessage());
                }
                isFirst = false;
                new_list.clear ();
            }
            Date end = new Date();
            long end_time = end.getTime();
            long during = (end_time - begin_time) / 1000;
            System.out.println("0-"+String.valueOf(max_n)+"��Χ�ڻ��ѵ�ʱ��Ϊ��"+String.valueOf(during)+"s");
            //begin_time = end_time;
            if (during >= 30*60){
                break;
            }
            else {
                max_n = max_n + (long)Math.pow(2,16);
            }
            if(!isFirst){
                new_list.clear ();
                for(long i = max_n - (long)Math.pow(2,16) + 1; i <= max_n; i++)
                    new_list.add (i);
                try{
                    for (int i = 0; i < prime_list.size (); i++ ){
                        long prime = prime_list.get (i);
                        for (long temp = prime*2; temp <= max_n; temp += prime ){
                            new_list.remove(temp);
                        }
                    }
                    prime_list.addAll (new_list);
                    //open a new file and record
                    FileWriter fw = new FileWriter("result.txt");
                    for (Object item : prime_list) {
                        fw.write(String.valueOf(item)+'\n');
                    }
                    //list.clear();
                    fw.close();
                }
                catch (Exception e)
                {
                    System.out.println(e.getMessage());
                }
            }



        }


    }

}
